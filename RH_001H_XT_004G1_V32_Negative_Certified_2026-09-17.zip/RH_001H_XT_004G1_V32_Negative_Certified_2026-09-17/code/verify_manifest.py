import hashlib, pathlib, sys
root = pathlib.Path(__file__).resolve().parents[1]
bad = []
for line in (root/"SHA256SUMS.txt").read_text().splitlines():
    if not line.strip():
        continue
    h, rel = line.split(None, 1)
    p = root / rel.strip()
    got = hashlib.sha256(p.read_bytes()).hexdigest()
    if got != h:
        bad.append((rel, h, got))
if bad:
    print("FAIL", bad)
    sys.exit(1)
print("PASS: internal SHA-256 inventory")
