from decimal import Decimal, getcontext
import json, pathlib, sys
getcontext().prec = 80
root = pathlib.Path(__file__).resolve().parents[1]
r = json.loads((root/"REPLAY_RESULTS.json").read_text())
for key in ["route_A", "route_B"]:
    lo = Decimal(r[key]["final_interval"][0])
    hi = Decimal(r[key]["final_interval"][1])
    if not (lo <= hi < 0):
        print("FAIL", key, lo, hi)
        sys.exit(1)
    print(key, "PASS", lo, hi)
print("V32_NEGATIVE_CERTIFIED arithmetic release condition PASS")
