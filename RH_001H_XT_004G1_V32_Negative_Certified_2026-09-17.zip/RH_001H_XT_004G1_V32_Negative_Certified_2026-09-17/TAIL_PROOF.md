# Tail Inequality Proof

For real \(z>0,t>0\),

\[
K_{it}(z)=\frac12\int_{-\infty}^{\infty}
e^{-z\cosh u+itu}\,du.
\]

For \(0<\theta<\pi/2\), shift the contour to \(u+i\theta\).
The vertical sides vanish by exponential decay.  Since

\[
\Re\cosh(u+i\theta)=\cosh u\cos\theta
\]

and

\[
|e^{it(u+i\theta)}|=e^{-t\theta},
\]

we obtain

\[
|K_{it}(z)|
\le e^{-t\theta}K_0(z\cos\theta).
\]

Differentiating under the integral gives a factor
\(\cosh(u+i\theta)\).  Since

\[
|\cosh(u+i\theta)|^2
=
\sinh^2u+\cos^2\theta
\le \cosh^2u,
\]

\[
|K'_{it}(z)|
\le e^{-t\theta}K_1(z\cos\theta).
\]

For \(a>0\),

\[
K_0(a)=\int_0^\infty e^{-a\cosh u}du
\le e^{-a}\sqrt{\frac{\pi}{2a}},
\]

using \(\cosh u\ge1+u^2/2\).

For \(a>1\), use
\(\log\cosh u\le u^2/2\), hence
\(\cosh u\le e^{u^2/2}\), to obtain

\[
K_1(a)
=
\int_0^\infty e^{-a\cosh u}\cosh u\,du
\le
e^{-a}\sqrt{\frac{\pi}{2(a-1)}}.
\]

These majorants are used with fixed proof angles, so no inverse-trigonometric
rounding enters the certified tail ledger.

For a fixed \(c=\cos\theta>0\) and \(Z>0\),

\[
\int_Z^\infty e^{-cz}z^\beta dz
\le
e^{-cZ}\frac{Z^\beta}{c-\beta/Z}
\]

whenever \(c-\beta/Z>0\), because
\(\log(z/Z)\le(z-Z)/Z\).

For the p>=5 sum, the elementary divisor bound
\(\tau(p)\le2\sqrt p\) is used.  Each remaining polynomial factor grows by at
most degree three, while the exponential factor decreases by
\(e^{-cA}\) per increment in p.  Hence the tail is bounded geometrically by
the p=5 term with ratio
\[
e^{-cA}(6/5)^3<1.
\]
