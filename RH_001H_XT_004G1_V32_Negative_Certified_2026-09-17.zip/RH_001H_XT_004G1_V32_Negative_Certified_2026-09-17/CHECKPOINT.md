# RH-001H XT-004G1 — Certified Negative V32(1/5) Sign

Date: 2026-09-17

Classification:

`V32_NEGATIVE_CERTIFIED`

## Theorem-level computer-assisted statement

Within the explicit arithmetic trust model stated in `PROOF_AND_AUDIT.md`,

\[
V_{32}(1/5)
=
2\int_{1/5}^{\infty}\sinh(7r/8)\Phi_r(32)\,dr
<0.
\]

An independently reconstructed r-domain certificate gives

\[
V_{32}(1/5)
\in
[-3.965087673290262031205937731170\times 10^{-19},
 -3.410440175927191319509719654804\times 10^{-19}].
\]

A separately replayed z-domain representation, with a corrected directed quadrature
remainder audit, gives

\[
V_{32}(1/5)
\in
[-3.900701435179151986360311138146\times 10^{-19},
 -3.474740016377126956333050414960\times 10^{-19}].
\]

Both upper endpoints are strictly negative.

## Consequence ceiling

This eliminates only the first-cumulative sufficient condition requiring the relevant
first cumulative quantity to be nonnegative everywhere.

It does NOT prove:
- failure of Fourier positivity;
- failure of all cumulative / iterated-tail criteria;
- a fixed zero-free strip;
- inward strip movement;
- RH or not-RH.

The lawful next branch is the iterated-tail / V2 branch.
