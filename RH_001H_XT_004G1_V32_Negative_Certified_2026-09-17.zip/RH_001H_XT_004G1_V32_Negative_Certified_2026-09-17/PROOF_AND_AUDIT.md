# Proof and Audit Record

## 1. Source binding

Canonical ancestor:
- RH-001H-CP-X-002
- SHA-256 `9ff24fe71440ee56eaa2a50af4456627bbeb1052ed6b2308df0ed7d187bc3a79`

Parent:
- RH-001H-XT-004F
- SHA-256 `429fca0f186c85f4d5aa9c40ccc41183c712a607811c6a23002f66d8956a9e8b`

Working predecessor:
- RH-001H-XT-004G working certificate
- SHA-256 `5b4f71b1c0bcfd975675577d61510374487839c1f794226818186426e554f5ac`

The working predecessor contained 21 hashed payload files; all 21 hashes were
recomputed and matched before promotion.

## 2. Algebraic audit

Let \(E=z\,d/dz\), \(t=32\), and

\[
B_t(z)=(z^2+9)K_{it}(z)+6zK'_{it}(z).
\]

The modified-Bessel equation

\[
z^2K''+zK'-(z^2-t^2)K=0
\]

gives \(E^2K=(z^2-t^2)K\), hence

\[
((E+3)^2+t^2)K
=(z^2+9)K+6zK'=B_t.
\]

For the \(I_{it}\)-series, the \(k\)-th term has Euler exponent \(2k+it\).
Therefore

\[
((E+3)^2+t^2)
\leadsto
(2k+3+it)^2+t^2
=
(2k+3)^2+2it(2k+3).
\]

For

\[
\mathcal I_\alpha(z_0;t)
=
\int_{z_0}^\infty z^\alpha B_t(z)\,dz,
\]

one integration by parts in the \(6zK'\) term gives

\[
\mathcal I_\alpha
=
-6z_0^{\alpha+1}K_{it}(z_0)
+
\int_{z_0}^\infty
[z^{\alpha+2}+(3-6\alpha)z^\alpha]K_{it}(z)\,dz.
\]

At \(\alpha=31/16\) and \(17/16\), the coefficients are exactly
\(-69/8\) and \(-27/8\).

## 3. Independent Route A reconstruction

The compact r-domain integral was recomputed from the weighted \(I_{it}\)-series,
not from stored compact sums.

Shared backend:
- Python `mpmath.iv` interval arithmetic.

Independent features:
- independent weighted-series implementation;
- independently recomputed midpoint partition;
- fixed rational-decimal contour angles rather than inverse-trigonometric
  optimizer values inside the proof ledger;
- independently directed remainder ledger.

Compact interval:

\[
[-3.687763924608726675357828774288\times10^{-19},
 -3.687763924608726675357828611686\times10^{-19}].
\]

Directed error ledger:
- midpoint quadrature: \(2.124454620206249803190938779524\times10^{-20}\);
- p=1..4 z>=50 tails: \(1.471035024053193373274568235823\times10^{-21}\);
- all p>=5: \(5.016793642037844179626939657169\times10^{-21}\).

Combined:
\[
2.773237486815353558481089568823\times10^{-20}.
\]

Final Route-A enclosure:

\[
[-3.965087673290262031205937731170\times10^{-19},
 -3.410440175927191319509719654804\times10^{-19}].
\]

Distance/error ratio using the compact upper endpoint:
\[
13.297685258263147\ldots
\]

Even ten times the entire remainder ledger leaves a negative upper endpoint:
\[
-9.14526437793373116876739042863\times10^{-20}<0.
\]

## 4. Route B replay and corrected remainder audit

All four compact z-domain computations were freshly replayed and reproduced the
working predecessor values.

Compact sum:

\[
[-3.687720725778139486036205833528\times10^{-19},
 -3.687720725778139456657155719579\times10^{-19}].
\]

Audit finding:
the predecessor helper `zquad_bound.py` evaluates every term of the second
derivative absolute-sum at the segment upper endpoint.  Two monomials have
negative powers after two differentiations, so that shortcut should not be used
as a rigorous supremum rule.

The repair evaluates each monomial at the correct endpoint according to the sign
of its exponent.  The corrected directed quadrature bound is

\[
1.481024227401021247950902256887\times10^{-20},
\]

which is still below the predecessor's rounded \(1.482\times10^{-20}\) ledger.

Using the independently directed tail bounds gives total Route-B remainder

\[
2.129807094010125003241053046186\times10^{-20}.
\]

Final Route-B enclosure:

\[
[-3.900701435179151986360311138146\times10^{-19},
 -3.474740016377126956333050414960\times10^{-19}].
\]

Distance/error ratio:
\[
17.314810980531968\ldots
\]

Ten times the complete remainder ledger still leaves a negative upper endpoint.

## 5. Trust boundary

This is a computer-assisted theorem under an explicit software-arithmetic trust model.

The compact special-function point enclosures use `mpmath.iv`; no Arb/python-flint
installation was available in the execution environment.

Therefore the independence classification is:

`INDEPENDENT_IMPLEMENTATION / SHARED_BACKEND`

and, for the pair of routes as a whole,

`PARTIALLY_SHARED_ANALYTIC_LEDGER`.

No claim of independent-backend formal verification is made.

The analytic contour-shift and Gaussian majorants were independently derived and
checked; see `TAIL_PROOF.md`.

## 6. Final classification

`V32_NEGATIVE_CERTIFIED`
