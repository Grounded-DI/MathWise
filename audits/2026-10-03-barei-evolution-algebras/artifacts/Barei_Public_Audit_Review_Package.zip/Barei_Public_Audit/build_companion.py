#!/usr/bin/env python3
"""Authored public companion and optional PDF builder.

Needs reportlab, matplotlib, and DejaVu fonts for PDF regeneration only.
verify_audit.py is unchanged and uses the Python standard library only.
"""
from pathlib import Path
from html import escape
import io
import matplotlib
matplotlib.use("Agg")
from matplotlib.mathtext import math_to_image
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                               TableStyle, PageBreak, Image)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "Barei_Public_Audit_Companion.pdf"
FONT = Path("/usr/share/fonts/truetype/dejavu")
for name, file in [("DV", "DejaVuSans.ttf"), ("DV-Bold", "DejaVuSans-Bold.ttf"),
                   ("DVM", "DejaVuSansMono.ttf")]:
    pdfmetrics.registerFont(TTFont(name, str(FONT / file)))
pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-Bold", italic="DV", boldItalic="DV-Bold")
NAVY = colors.HexColor("#17314b")
TEAL = colors.HexColor("#176b62")
MUTED = colors.HexColor("#526477")
LIGHT = colors.HexColor("#edf3f7")
W = 504
styles = {
    "body": ParagraphStyle("body", fontName="DV", fontSize=9.4, leading=13.6,
                           textColor=NAVY, spaceAfter=7.5),
    "small": ParagraphStyle("small", fontName="DV", fontSize=8.1, leading=11.5,
                            textColor=NAVY, spaceAfter=6),
    "title": ParagraphStyle("title", fontName="DV-Bold", fontSize=22, leading=27,
                            textColor=NAVY, spaceAfter=12),
    "heading": ParagraphStyle("heading", fontName="DV-Bold", fontSize=16.5, leading=22,
                              textColor=NAVY, spaceAfter=11),
    "sub": ParagraphStyle("sub", fontName="DV-Bold", fontSize=10.4, leading=14,
                          textColor=TEAL, spaceBefore=7, spaceAfter=6),
    "label": ParagraphStyle("label", fontName="DV-Bold", fontSize=8, leading=11,
                            textColor=TEAL, spaceAfter=9),
    "cell": ParagraphStyle("cell", fontName="DV", fontSize=8.25, leading=11.3,
                           textColor=NAVY),
    "cellhead": ParagraphStyle("cellhead", fontName="DV-Bold", fontSize=8.25,
                               leading=11.3, textColor=colors.white),
}
story = []


def p(s, style="body"):
    story.append(Paragraph(s, styles[style]))


def sub(s): p(s, "sub")


def page(number, title):
    if number > 1: story.append(PageBreak())
    p("PUBLIC AUDIT COMPANION / DRAFT FOR REVIEW / " + str(number).zfill(2), "label")
    p(title, "title" if number == 1 else "heading")


def eq(s):
    b = io.BytesIO()
    math_to_image("$"+s+"$", b, dpi=240, format="png", color="#17314b")
    data = b.getvalue(); width, height = ImageReader(io.BytesIO(data)).getSize()
    scale = min(72/240*1.18, W/width)
    im = Image(io.BytesIO(data), width=width*scale, height=height*scale)
    im.hAlign = "LEFT"
    story.extend([Spacer(1,3), im, Spacer(1,8)])


def table(headers, rows, widths, pad=6):
    data = [[Paragraph(escape(str(x)), styles["cellhead"]) for x in headers]]
    data += [[Paragraph(str(x), styles["cell"]) for x in row] for row in rows]
    t = Table(data, colWidths=widths, hAlign="LEFT", repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND",(0,0),(-1,0),NAVY),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,LIGHT]),
        ("VALIGN",(0,0),(-1,-1),"TOP"),
        ("LEFTPADDING",(0,0),(-1,-1),7),
        ("RIGHTPADDING",(0,0),(-1,-1),7),
        ("TOPPADDING",(0,0),(-1,-1),pad),
        ("BOTTOMPADDING",(0,0),(-1,-1),pad),
    ]))
    story.extend([t,Spacer(1,9)])


def matrix(label, rows, width=152):
    t = Table([[str(x) for x in r] for r in rows],
              colWidths=[width/len(rows[0])]*len(rows[0]))
    t.setStyle(TableStyle([
        ("FONTNAME",(0,0),(-1,-1),"DVM"),("FONTSIZE",(0,0),(-1,-1),9.8),
        ("ALIGN",(0,0),(-1,-1),"CENTER"),
        ("TOPPADDING",(0,0),(-1,-1),3),("BOTTOMPADDING",(0,0),(-1,-1),3),
        ("LINEBEFORE",(0,0),(0,-1),.6,NAVY),("LINEAFTER",(-1,0),(-1,-1),.6,NAVY)]))
    wrap=Table([[Paragraph(label,styles["body"]),t]],colWidths=[118,width],hAlign="LEFT")
    wrap.setStyle(TableStyle([("LEFTPADDING",(0,0),(-1,-1),0),
                             ("VALIGN",(0,0),(-1,-1),"MIDDLE")]))
    story.extend([wrap,Spacer(1,8)])


page(1,"Barei evolution algebra audit confirmation")
p("<b>The principal mathematics survived the bounded audit under the stated hypotheses.</b> No fatal mathematical error was found in the reconstructed principal claims. All eleven exact check groups also passed on a fresh rerun.")
p("Subject: Andres Barei’s <i>On Solvable Evolution Algebras and a Conjecture by García-Martínez and Pérez-Rodríguez</i>. The manuscript credits Muse Spark and names Nicolás Jaramillo Torres as reviewer. This separate audit was commissioned by <b>Mark S. Weinstein</b> and prepared with AI assistance.")
p("Prepared 3 October 2026. This companion preserves the earlier detailed audit and records a follow-up in the same assistant workflow. It is source-informed, not blind replication, an independent human expert review, or a proof-assistant formalization. The material remains a draft for review; nothing has been published or sent to the authors.","small")
table(["Principal claim", "Verdict", "Scope / value of the audit"],[
    ["Example 2.1", "Supported", "Nonsolvable over C; zero is the only complex idempotent. Complete two-branch elimination supplied."],
    ["Lemma 3.1", "Supported", "Greatest perfect subspace follows from descent, stabilization and inclusion."],
    ["Theorem 3.2", "Supported", "Elementary stable-series characterization; valid for general finite-dimensional algebras."],
    ["Theorem 3.3", "Supported", "A precise older existence theorem supplies a concise alternative to the compressed geometric step."],
    ["Corollary 3.4", "Supported", "Apply the existence result directly to the stable term. Its sufficient condition is strictly broader than Hu–Wen’s."],
    ["Remarks 3.5–3.6", "Qualified", "3.6 is supported. 3.5 is a search observation, not a proved universal statement."],
],[118,69,317])
sub("What the audit contributes")
p("It supplies a readable counterexample calculation, simpler proof routes, an explicit isomorphism with Hu–Wen’s exceptional example, and a four-dimensional witness proving strictness of the sufficient-condition comparison. The witness was independently constructed in the earlier audit and rechecked here; its historical novelty has not been established.")
sub("Assumptions and credit")
p("The abstract claims concern finite-dimensional evolution algebras over an algebraically closed field; Example 2.1 is over C. Multiplication is bilinear and generally nonassociative. The derived term is the span of all products in the preceding term. Natural-basis mixed products are zero.","small")
p("Credit: Barei; named paper reviewer Nicolás Jaramillo Torres; Muse Spark as attributed by the authors; original conjecture authors Xabier García-Martínez and Andrés Pérez-Rodríguez; concurrent authors Xing-Yu Hu and Ran Wen; and Yuri Lyubich and Alexander Tsukerman for the older existence theorem. These credits imply no endorsement of this audit.","small")

page(2,"The calculation and added witness")
sub("An exhaustive complex-idempotent calculation")
p("Rows of Barei’s matrix encode eᵢ²; mixed natural-basis products vanish. Let r₁ = (−2,0,2), r₂ = (0,1,−1). Then r₁² = 4(r₁ − r₂), r₁r₂ = 2r₂, and r₂² = 0. Hence the derived dimensions are 3 → 2 → 2: the algebra is nonsolvable.")
eq(r"x=-2x^2,\quad y=y^2-z^2,\quad z=2x^2-y^2+z^2.")
p("The first equation forces x = 0 or −1/2. Put s = y + z = 2x². The other equations force (1 − 2s)y = −s². For x = 0, y = z = 0. For x = −1/2, 0 = −1/4 is impossible. These two branches exhaust every complex solution; the code evaluates their exact coefficients.")
sub("A shorter route through the stable term")
p("Descent and finite-dimensional stabilization give D² = D. Every V with V² = V lies in every derived term, hence in D. This proves Lemma 3.1 and makes Theorem 3.2 immediate. No evolution-algebra structure is needed for these stable-series facts.")
p("Lyubich–Tsukerman’s Theorem 2.1 states the idempotent-or-square-zero existence property for finite-dimensional algebras over any algebraically closed field. A nonzero subalgebra with N(V) = {0} therefore contains an idempotent. This proves the substantive converse of Theorem 3.3; applying it to D directly proves Corollary 3.4. Its classical geometric proof was reviewed separately from the executable checks.")
sub("Strictness witness over C")
matrix("Four-dimensional W",[[1,0,-1,0],[1,1,0,1],[0,1,-1,-1],[0,0,1,1]],width=176)
p("This natural-basis matrix has stable term D = {(x,y,z,x+z)} and derived dimensions 4 → 3 → 3. In D coordinates:")
eq(r"(x,y,z)(u,v,w)=(xu+yv,\;yv+zw,\;xw+zu).")
p("A square-zero vector satisfies x² + y² = y² + z² = 2xz = 0. Since xz = 0, either branch forces x = y = z = 0. Thus N(D) = {0}.")
p("The three coordinate bilinear forms have matrices B₁ = diag(1,1,0), B₂ = diag(0,1,1), and B₃ with ones at (1,3),(3,1). Let B₀ = B₁ + B₂. A natural basis would simultaneously diagonalize the forms by congruence, forcing B₀⁻¹B₁ and B₀⁻¹B₃ to commute. Their commutator has entries 1 at (1,3) and −1 at (3,1), so no natural basis exists.")
p("Consequently this evolution algebra satisfies Barei’s N(D) = {0} condition while failing Hu–Wen’s condition that D be an evolution algebra. It proves strict enlargement of the sufficient hypothesis. Exact code checks the embedding, product identities, commutator and an idempotent; the quantified arguments above are separately reasoned.","small")

page(3,"Claims mapped to evidence")
p("Primary locations use printed PDF pages. “Audit” refers to the unchanged twelve-page detailed report. Every conclusion below was revisited in this follow-up; the original construction and proofs are carried forward rather than presented as new discoveries. CLAIM_EVIDENCE.csv supplies the full fourteen-row mapping.","small")
table(["Publication statement", "Exact source location", "Evidence and limit"],[
    ["Counterexample survives", "Barei Example 2.1, pp. 2–3; GP Conjecture 3.6, p. 602 / PDF p. 6", "Audit p. 3; C01–C03 plus exhaustive branch argument. Matrix identities alone do not establish solution completeness."],
    ["Stable-series characterizations survive", "Barei §2, p. 2; Lemma 3.1 and Theorem 3.2, p. 3", "Audit p. 4; induction, stabilization and greatest-subspace proof. C02 illustrates the result for this example."],
    ["Theorem 3.3 survives with explicit support", "Barei p. 3; LT Theorem 2.1, p. 2; Lemma 3.2, pp. 4–5; proof p. 5", "Audit p. 5; homogeneous quadrics, simple trivial point, proper finite-intersection Bézout and scaling. No executable proof of the geometric theorem."],
    ["Corollary 3.4 follows directly", "Barei pp. 3–4", "Audit p. 6; apply the existence lemma to D itself. Finite dimension and field hypotheses retained."],
    ["Hu–Wen hypothesis implies Barei’s", "Barei Remark 3.6, p. 4; HW Proposition 2.8, p. 6", "Audit p. 6; independence of the natural-basis squares in perfect D forces N(D) = {0}."],
    ["Counterexamples have the same class", "Barei Example 2.1; HW Theorem 2.1 / Corollary 2.2, p. 3; exceptional matrix p. 4", "Audit p. 7; C04 verifies e₁ ↦ −h₂, e₂ ↦ h₃, e₃ ↦ −h₁ and all nine products. No discovery-provenance inference."],
    ["The sufficient condition is strictly broader", "Audit construction compared with Barei Corollary 3.4 and HW Proposition 2.8", "Audit p. 8; C05–C06 plus square-zero completeness and congruence obstruction. No historical novelty claim for the witness."],
    ["AI collaboration is author-reported", "Barei title / AI-use statement, p. 1; Meta announcement, sixth-paper section", "Audit p. 10; manuscript labels and official account. Interaction records are absent; causal model contribution is not independently reconstructed."],
    ["Novelty and open questions remain bounded", "HW counterexample p. 3; LT existence theorem p. 2; Barei Remark 3.5 p. 4", "Audit pp. 6–7,10,12; named sources establish overlap and the older ingredient. Global priority and the search question remain unresolved."],
],[137,147,220],pad=6)
sub("The geometric dependency is disclosed")
p("For a nonzero n-dimensional subalgebra, consider Qⱼ(x) − txⱼ = 0 in projective n-space. The point (0:1) has Jacobian −I in the t = 1 chart and multiplicity one. An infinite solution set has another point; a finite proper intersection has degree 2ⁿ &gt; 1. A nontrivial point gives a square-zero element or, after scaling by t, an idempotent. Algebraic closure supplies solutions in the ground field. Vakil’s exercise 1.8 (p. 4) and §1.10 (p. 6) support the qualified degree product.","small")
p("The exact Harris fixed-point page cited generally by Barei remains unresolved; the needed existence result is supported by LT. Direct verification of the older 2017 classification row, first-discovery chronology and model-interaction provenance also remain unresolved.","small")

page(4,"Actual results and how to inspect them")
p("<b>Fresh rerun:</b> Python 3.12.14; exit code 0; <b>11 of 11 exact groups PASS</b>. Recorded at 2026-10-03 15:04:32 UTC / 11:04:32 a.m. EDT. The unchanged checker’s evidence records match the earlier results. Five freshly downloaded central primary PDFs match the earlier source hashes.")
p("Run from the package directory without Python optimization:<br/><font face='DVM'>python3 verify_audit.py --output my_results.json</font>","small")
table(["Groups", "Finite computation / branch-check scope", "Result"],[
    ["C01–C03", "Counterexample products, derived dimensions [3,2,2], coefficients in all analytically forced idempotent branches.", "PASS"],
    ["C04", "Invertible signed permutation; nine basis-product identities with Hu–Wen E₂.", "PASS"],
    ["C05–C06", "Four-dimensional witness embedding, nine identities, dimensions [4,3,3], nonzero commutator and one idempotent.", "PASS"],
    ["C07", "All nine vectors in the F₃ field-hypothesis example: only zero is square-zero or idempotent.", "PASS"],
    ["C08", "Barei’s numeric example reduces in characteristic two to dimensions [3,1,0,0], hence is solvable.", "PASS"],
    ["C09", "A perfect dual-number stable term shows the sufficient condition is not necessary for equivalence in each algebra.", "PASS"],
    ["C10", "Deleting the +2e₃ coefficient introduces the idempotent −e₁/2; the negative control detects it.", "PASS"],
    ["C11", "A square-zero-free line lacks multiplication closure; arbitrary vector subspaces do not suffice.", "PASS"],
],[65,393,46],pad=5)
sub("Correctness, reproducibility and integrity")
p("The mathematical conclusions rest on the stated calculations and proof dependencies. Reproducibility is supported by the unchanged program and actual outputs. File integrity is supported by SHA-256 comparison with trusted reference bytes. The original archive’s seven listed file hashes and ZIP check pass; matching hashes do not prove mathematics or authorship.","small")
p("The full claim table, exact outputs, run log, source records and preserved earlier artifacts accompany this PDF. The geometric existence result, infinite-dimensional argument, witness square-zero proof and implication from a natural basis to commuting operators are reasoning checks, not machine-verified universal theorems. No Grounded DI or Protocol A causal benefit is claimed.","small")
sub("Primary sources and credit links")
refs=[
    ("Barei / Meta manuscript and original attribution", "https://ai.meta.com/research/publications/on-solvable-evolution-algebras-and-a-conjecture-by-garcia-martinez-and-perez-rodriguez/"),
    ("García-Martínez and Pérez-Rodríguez / original conjecture", "https://doi.org/10.1007/s00013-026-02251-0"),
    ("Hu and Wen / concurrent counterexample and condition", "https://arxiv.org/pdf/2609.25023"),
    ("Lyubich and Tsukerman / 2014 existence theorem", "https://arxiv.org/pdf/1403.4623"),
    ("Vakil / properly qualified Bézout notes", "https://math.stanford.edu/~vakil/0506-216/216class31.pdf"),
    ("Meta / public account of the collaboration", "https://research.meta.ai/blog/solving-open-research-problems-together"),
]
for label,url in refs:p('<link href="'+escape(url,quote=True)+'" color="#176b62">'+escape(label)+'</link>',"small")


def footer(canvas,doc):
    canvas.saveState();canvas.setStrokeColor(colors.HexColor("#c7d3de"))
    canvas.line(54,42,558,42);canvas.setFont("DV",7);canvas.setFillColor(MUTED)
    canvas.drawString(54,29,"MSW / AI-assisted bounded audit / 3 October 2026 / Draft for review")
    canvas.drawRightString(558,29,str(doc.page));canvas.restoreState()


doc=SimpleDocTemplate(str(OUT),pagesize=(612,792),leftMargin=54,rightMargin=54,
                      topMargin=45,bottomMargin=57,
                      title="Barei Public Audit Companion Draft",
                      author="AI-assisted audit commissioned by Mark S. Weinstein",
                      subject="Public confirmation, proof simplifications, strictness witness, scope and evidence")
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUT)
