#!/usr/bin/env python3
"""Build the accompanying audit PDF. Optional dependencies: reportlab, matplotlib.

The independent checking program verify_audit.py uses the standard library only.
This file also preserves the report's full authored content.
"""
from pathlib import Path
from html import escape
import io
import json

import matplotlib
matplotlib.use("Agg")
from matplotlib.mathtext import math_to_image
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                               TableStyle, PageBreak, Image, KeepTogether)

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "Barei_Evolution_Algebra_Audit.pdf"
FONT_ROOT = Path("/usr/share/fonts/truetype/dejavu")
pdfmetrics.registerFont(TTFont("DV", str(FONT_ROOT / "DejaVuSans.ttf")))
pdfmetrics.registerFont(TTFont("DV-Bold", str(FONT_ROOT / "DejaVuSans-Bold.ttf")))
pdfmetrics.registerFont(TTFont("DVM", str(FONT_ROOT / "DejaVuSansMono.ttf")))
pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-Bold", italic="DV", boldItalic="DV-Bold")
NAVY = colors.HexColor("#17314b")
TEAL = colors.HexColor("#176b62")
MUTED = colors.HexColor("#526477")
LIGHT = colors.HexColor("#edf3f7")
WIDTH = 504
styles = {
    "body": ParagraphStyle("body", fontName="DV", fontSize=9.2, leading=13.5,
                           textColor=NAVY, spaceAfter=7.5),
    "small": ParagraphStyle("small", fontName="DV", fontSize=8, leading=11.5,
                            textColor=NAVY, spaceAfter=6),
    "title": ParagraphStyle("title", fontName="DV-Bold", fontSize=23, leading=28,
                            textColor=NAVY, spaceAfter=13),
    "heading": ParagraphStyle("heading", fontName="DV-Bold", fontSize=17, leading=22,
                              textColor=NAVY, spaceAfter=13),
    "sub": ParagraphStyle("sub", fontName="DV-Bold", fontSize=10.5, leading=14,
                          textColor=TEAL, spaceBefore=7, spaceAfter=6),
    "label": ParagraphStyle("label", fontName="DV-Bold", fontSize=8, leading=11,
                            textColor=TEAL, spaceAfter=9),
    "cell": ParagraphStyle("cell", fontName="DV", fontSize=8.1, leading=11.5,
                           textColor=NAVY),
    "cellhead": ParagraphStyle("cellhead", fontName="DV-Bold", fontSize=8.1,
                               leading=11.5, textColor=colors.white),
    "code": ParagraphStyle("code", fontName="DVM", fontSize=8.3, leading=12.5,
                           textColor=NAVY, spaceAfter=7),
}
story = []


def p(text, style="body"):
    story.append(Paragraph(text, styles[style]))


def sub(text):
    p(text, "sub")


def page(number, title):
    if number > 1:
        story.append(PageBreak())
    p("BOUNDED MATHEMATICAL AUDIT  /  " + str(number).zfill(2), "label")
    p(title, "title" if number == 1 else "heading")


def eq(tex, max_width=WIDTH, font_size=12):
    buf = io.BytesIO()
    math_to_image("$" + tex + "$", buf, dpi=230, format="png", color="#17314b")
    data = buf.getvalue()
    w, h = ImageReader(io.BytesIO(data)).getSize()
    scale = min(font_size / 10 * 72 / 230, max_width / w)
    im = Image(io.BytesIO(data), width=w*scale, height=h*scale)
    im.hAlign = "LEFT"
    story.extend([Spacer(1, 3), im, Spacer(1, 9)])


def table(headers, rows, widths):
    data = [[Paragraph(escape(str(x)), styles["cellhead"]) for x in headers]]
    data.extend([[Paragraph(str(x), styles["cell"]) for x in row] for row in rows])
    t = Table(data, colWidths=widths, hAlign="LEFT", repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), NAVY),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, LIGHT]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING", (0,0), (-1,-1), 8),
        ("RIGHTPADDING", (0,0), (-1,-1), 8),
        ("TOPPADDING", (0,0), (-1,-1), 7),
        ("BOTTOMPADDING", (0,0), (-1,-1), 7),
        ("LINEBELOW", (0,0), (-1,0), .5, NAVY),
    ]))
    story.extend([t, Spacer(1, 10)])


def matrix(label, rows, width=150):
    # Actual matrix entries as a crisp typeset table, with a descriptive label.
    label_para = Paragraph(label, styles["body"])
    grid = Table([[str(v) for v in row] for row in rows],
                 colWidths=[width / len(rows[0])] * len(rows[0]))
    grid.setStyle(TableStyle([
        ("FONTNAME", (0,0), (-1,-1), "DVM"),
        ("FONTSIZE", (0,0), (-1,-1), 10),
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("TOPPADDING", (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("LINEBEFORE", (0,0), (0,-1), .7, NAVY),
        ("LINEAFTER", (-1,0), (-1,-1), .7, NAVY),
    ]))
    outer = Table([[label_para, grid]], colWidths=[120, width], hAlign="LEFT")
    outer.setStyle(TableStyle([("VALIGN", (0,0), (-1,-1), "MIDDLE"),
                              ("LEFTPADDING", (0,0), (-1,-1), 0)]))
    story.extend([outer, Spacer(1, 10)])


page(1, "The main mathematics survives")
p("Audit of Andres Barei’s <b>On Solvable Evolution Algebras and a Conjecture by García-Martínez and Pérez-Rodríguez</b>, developed with Muse Spark. Prepared for Mark. Evidence retrieved and checks run on 3 October 2026 UTC; Meta’s public release is dated 2 October 2026.")
p("<b>Verdict:</b> no fatal mathematical error found in the principal claims under the manuscript’s stated assumptions. The counterexample has an exhaustive exact proof. The stable-series arguments are elementary and more general than evolution algebras. The compressed geometric step is valid once its precise existence lemma is supplied. Novelty and AI attribution need separate qualifications.")
table(["Claim / Barei location", "Verdict", "Independent finding"], [
    ["Conjecture 1.1; Example 2.1<br/>pp. 1–3", "Disproof survives", "Derived dimensions 3 → 2 → 2; zero is the only complex idempotent. The example is isomorphic to Hu–Wen’s E₂."],
    ["Lemma 3.1<br/>p. 3", "Correct", "The stable term contains every V with V² = V. Holds for any finite-dimensional algebra with bilinear multiplication."],
    ["Theorem 3.2<br/>p. 3", "Correct; elementary", "A consequence of stabilization and Lemma 3.1. It restates solvability structurally; it is not an evolution-specific classification algorithm."],
    ["Theorem 3.3<br/>p. 3", "Correct; expose import", "Use the known idempotent-or-square-zero theorem. The projective fixed-point sentence needs an explicit lemma and hypotheses."],
    ["Corollary 3.4<br/>pp. 3–4", "Correct", "Its sufficient condition is strictly broader than Hu–Wen Proposition 2.8. A four-dimensional witness is constructed here."],
    ["Remarks 3.5–3.6<br/>p. 4", "3.6 correct; 3.5 open lead", "The comparison follows from independent squares in a perfect evolution algebra. Remark 3.5 reports a search observation, not a proved theorem."],
], [135, 99, 270])
p("<b>Evidence labels.</b> “Source assertion” records what the authors say. “Independently checked” means a reconstruction in this audit, sometimes backed by exact code. “Unresolved” marks a missing source, provenance record, or global-priority determination. Eleven computational check groups pass; the universal proofs are assessed separately.", "small")

page(2, "Claims, assumptions, and conventions")
sub("The original claim")
p("García-Martínez–Pérez-Rodríguez [GP], published §3.3, Conjecture 3.6, printed p. 602 / PDF p. 6, proposes for a <b>finite-dimensional complex evolution algebra</b> that solvability, absence of nonzero idempotents, and having only the zero solution of the idempotent system are equivalent. The finite-dimensional scope is fixed at the start of §3. The wording “no idempotents” must mean no <i>nonzero</i> idempotents, since zero is always idempotent.")
p("The solvable ⇒ no nonzero idempotent direction is universally valid. The false direction is no nonzero idempotent ⇒ solvable. Barei’s Conjecture 1.1 isolates that equivalence; Example 2.1 refutes it. Theorems 3.2–3.3 and Corollary 3.4 are separate replacement statements, each requiring its own proof.")
sub("Barei’s standing hypotheses, §2, p. 2")
p("The field K is <b>algebraically closed</b>. No characteristic exclusion is stated. Each theorem explicitly concerns a <b>finite-dimensional</b> evolution algebra with a distinguished natural basis e₁,…,eₙ. Multiplication is bilinear and commutative, with eᵢeⱼ = 0 for i ≠ j; associativity is not assumed. Example 2.1 is specifically over ℂ.")
eq(r"e_i^2=\sum_j m_{ij}e_j,\qquad M^T(x_1^2,\ldots,x_n^2)^T=(x_1,\ldots,x_n)^T")
p("Rows of M are the coordinates of the basis squares. The transpose in the idempotent system matters. The checking code uses the same row convention.")
table(["Notation", "Precise meaning"], [
    ["V²", "span{xy : x,y ∈ V}; span of all products, not just the set of squares."],
    ["E⁽¹⁾ = E; E⁽ᵏ⁺¹⁾ = (E⁽ᵏ⁾)²", "Derived series under the paper’s definition of solvability. No associative-power convention is substituted."],
    ["D = E⁽∞⁾", "The eventual stable derived term, defined using finite-dimensional stabilization."],
    ["“Idempotent subspace”", "V² = V, also called a perfect subalgebra here. This is distinct from an idempotent element e² = e."],
    ["N(V) = {v ∈ V : v² = 0}", "A set, usually not a vector subspace. N(V) = 0 means N(V) = {0}. “Absolutely nilpotent” means square-zero."],
], [168, 336])
p("<b>Important characteristic distinction:</b> Example 2.1 extends to fields of characteristic ≠ 2, but its numeric matrix becomes solvable in characteristic 2. The abstract arguments of Lemma 3.1–Corollary 3.4 remain valid over algebraically closed fields in every characteristic; the existence lemma used below has no characteristic restriction.", "small")

page(3, "The counterexample, reconstructed")
p("[B], Example 2.1, pp. 2–3. All products below are obtained directly from this matrix and the off-diagonal-zero convention.")
matrix("Structure matrix M", [[-2,0,2],[0,1,-1],[0,-1,1]])
eq(r"r_1=e_1^2=-2e_1+2e_3,\quad r_2=e_2^2=e_2-e_3,\quad r_3=e_3^2=-r_2")
eq(r"r_1^2=4(r_1-r_2),\qquad r_1r_2=2r_2,\qquad r_2^2=0")
p("The two vectors r₁,r₂ are independent. Thus E² = span{r₁,r₂} = D. The displayed products span D again: r₂ comes from r₁r₂, and then r₁ comes from r₁². Consequently E⁽ᵏ⁾ = D ≠ 0 for every k ≥ 2. The algebra is <b>not solvable</b>. Exact code checks C01–C02 reproduce this, including the coordinate product r₁² = (−8,−4,12).")
sub("Every complex idempotent is covered")
eq(r"x=-2x^2,\qquad y=y^2-z^2,\qquad z=2x^2-y^2+z^2")
p("The first equation factors as x(1 + 2x) = 0, so x is exactly 0 or −1/2 in ℂ. Add the other two equations and put s = y + z = 2x². Then y = (y − z)s = (2y − s)s, so")
eq(r"(1-2s)y=-s^2.")
table(["Forced x", "Forced s", "Remaining equation", "Outcome"], [
    ["0", "0", "y = 0; z = s − y = 0", "Only (0,0,0)"],
    ["−1/2", "1/2", "0 = −1/4", "Impossible"],
], [84, 85, 210, 125])
p("These are <b>all</b> branches because the first equation has exactly those two roots in a field of characteristic ≠ 2. The remaining equalities are necessary for every solution. The surviving zero vector also satisfies all three original equations. This is an exhaustive algebraic elimination, not a finite search over candidate complex numbers. C03 evaluates the branch coefficients with exact rational arithmetic.")
sub("An even shorter proof inside D")
p("Every idempotent lies in E² = D. Write a = r₁/2, b = r₂. Then a² = 2a − b, ab = b, b² = 0. If αa + βb is idempotent, 2α² = α and −α² + 2αβ = β. For α = 0, β = 0; for α = 1/2, the second equation reduces to −1/4 = 0. This simultaneously explains why a perfect two-dimensional subalgebra need not contain a nonzero idempotent.", "small")

page(4, "Derived series: every implication")
sub("Descent, closure, and stabilization")
p("These arguments use only bilinearity; they apply to an arbitrary finite-dimensional algebra A over any field, even without commutativity or associativity. Start with W = A, a subalgebra. If W is a subalgebra, W² ⊆ W. Products of elements of W² are therefore products of elements of W, so (W²)² ⊆ W². Hence W² is itself a subalgebra. Induction proves descent and closure for every derived term.")
eq(r"A=A^{(1)}\supseteq A^{(2)}\supseteq\cdots")
p("A strict inclusion lowers the nonnegative integer dimension. In finite dimension some consecutive terms have equal dimensions, hence are equal as subspaces. Once A⁽ˡ⁾ = A⁽ˡ⁺¹⁾, applying the same squaring operation keeps all later terms equal. D = A⁽ˡ⁾ is well defined and D² = D. No claim that a derived term is an ideal or admits a natural basis is needed.")
sub("Lemma 3.1: greatest perfect subspace")
p("If V² = V and V ⊆ A, then V = V² ⊆ A². Inductively, V ⊆ A⁽ᵏ⁾ implies V = V² ⊆ (A⁽ᵏ⁾)² = A⁽ᵏ⁺¹⁾. Thus V lies in every term, and in D. Since D² = D, D is the <b>greatest</b> perfect subspace by inclusion, not merely one maximal choice. This is exactly the claim on [B] p. 3.")
sub("Theorem 3.2 and the universal easy direction")
eq(r"A\ \mathrm{solvable}\ \Longleftrightarrow\ D=0\ \Longleftrightarrow\ \nexists\,V\ne0\ \mathrm{with}\ V^2=V")
p("The first equivalence is stabilization plus the definition of solvability. For the second, a nonzero D is itself a counter-witness; every other perfect subspace lies in D. This is an elementary structural consequence of the definition, with no evolution-algebra-specific content.")
p("If e² = e, then e lies in every derived term by induction: membership in one term implies e = e² lies in the next. Thus solvability always rules out nonzero idempotents, over every field and even in infinite dimension. This implication is used by both the original conjecture and Corollary 3.4.")
sub("Why finite dimension cannot simply be deleted")
p("Take the infinite-dimensional evolution algebra with basis e₀,e₁,…, finite-support vectors, eᵢ² = eᵢ₊₁, and distinct basis products zero. Its kth derived term is span{eᵢ : i ≥ k − 1}; the chain never stabilizes and the algebra is not solvable. Yet no nonzero subspace V satisfies V² = V: among all nonzero coefficients in vectors of V there is a least index m; every product of two such vectors has all indices ≥ m + 1, so V² cannot contain a vector of V with a nonzero coefficient at m. Thus absence of perfect subspaces alone does not characterize solvability in infinite dimension.", "small")

page(5, "The geometric step made explicit")
p("[B], Theorem 3.3, p. 3: a nonzero idempotent exists iff some nonzero V satisfies V² = V and N(V) = {0}. Forward: for e² = e ≠ 0, V = Ke has V² = V and (te)² = t²e, so only t = 0 is square-zero. The existence formulation allows a one-dimensional witness containing the very idempotent being sought.")
sub("Projectivization and scaling")
p("Conversely, V² = V gives multiplication closure. In coordinates, Q(v) = v² is a homogeneous quadratic polynomial map V → V. Homogeneity ensures [Q(cv)] = [Q(v)] for c ≠ 0. N(V) = {0} ensures Q(v) ≠ 0 for every nonzero v, so its homogeneous coordinates have no common projective zero. They define a <b>morphism</b> P(V) → P(V), [v] ↦ [v²]. The paper then asserts a fixed point because K is algebraically closed. The special homogeneous/projective-space existence result is the missing explicit dependency; algebraic closure alone is not a fixed-point principle for arbitrary varieties.")
p("At a fixed point, v² = λv with v ≠ 0 and λ ≠ 0. Set e = v/λ: e² = v²/λ² = v/λ = e. This scaling is valid in every characteristic.")
sub("A precise primary result supplies the dependency")
p("Lyubich–Tsukerman [LT], Theorem 2.1, p. 2, proof p. 5, establishes: every nonzero finite-dimensional algebra over an algebraically closed field has a nonzero idempotent or a nonzero square-zero element. Their general definition assumes only bilinear multiplication. The algebraically closed-field theorem, unlike their broader field-classification theorem, has <b>no characteristic exclusion</b>. Apply it to V; N(V) = {0} excludes the square-zero alternative. This yields the converse directly.")
sub("Short independent reconstruction of the imported existence argument")
p("Let dim V = n ≥ 1, and write Q = (Q₁,…,Qₙ). In Pⁿ(K), consider the n homogeneous quadrics")
eq(r"Q_j(x_1,\ldots,x_n)-t x_j=0\qquad (j=1,\ldots,n).")
p("The point (0:…:0:1) is a solution. In the affine chart t = 1 the Jacobian there is −I, since Q has no linear terms. Thus it is an isolated simple solution of multiplicity one, in every characteristic. If the projective solution set is infinite, another point exists. If it is finite, proper-intersection Bézout gives total multiplicity 2ⁿ &gt; 1, so another point again exists. At that point x ≠ 0. If t = 0, x² = 0; if t ≠ 0, x/t is idempotent. N(V) = {0} rules out t = 0.")
p("The finite-intersection hypothesis is stated before invoking Bézout; no inference from “no common divisor” to a finite intersection is used. [LT] Lemma 3.2 proves simplicity via the local-ring linear terms; [V] supplies proper-intersection / complete-intersection degree. Harris [Har92] is cited generally by Barei; its exact fixed-point locator was not verified. The needed dependency is verified through [LT] and the explicit reconstruction above.", "small")

page(6, "Corollary, comparison, and simpler proofs")
sub("Corollary 3.4, pp. 3–4")
p("Assume N(D) = {0}. If E is solvable, its only idempotent is zero, as proved on audit p. 4. If E is not solvable, D ≠ 0 and D² = D. Apply Theorem 3.3, or directly [LT], <b>to D itself</b> to obtain a nonzero idempotent. This avoids the manuscript’s extra step of choosing an arbitrary perfect V ⊆ D. The condition is sufficient; it is not asserted to be necessary.")
eq(r"N(D)=\{0\}\quad\Longrightarrow\quad(E\ \mathrm{solvable}\ \Longleftrightarrow\ E\ \mathrm{has\ no\ nonzero\ idempotent}).")
p("Both this corollary and Theorem 3.3 hold for arbitrary finite-dimensional algebras with bilinear multiplication over an algebraically closed field. The natural basis plays no role in these proofs. Indeed, for the nonzero-square-zero-free witness in Theorem 3.3, multiplication closure V² ⊆ V suffices for the converse; requiring V² = V is stronger than that proof needs.")
sub("Remark 3.6, p. 4; Hu–Wen Proposition 2.8, p. 6")
p("Suppose D itself is an evolution algebra with a natural basis f₁,…,fₘ. Since D² = D, its m vectors f₁²,…,fₘ² span the m-dimensional space D, hence are a basis. For v = Σtᵢfᵢ, off-diagonal-zero multiplication gives v² = Σtᵢ²fᵢ². Linear independence forces every tᵢ² = 0, hence every tᵢ = 0 over a field. Thus N(D) = {0}. This part requires a natural basis for <b>D itself</b>, not that the original natural basis of E restricts to D. It holds over any field.")
p("Consequently Barei’s condition implies the complex-field result of Hu–Wen Proposition 2.8, whose sufficient hypothesis is that D is an evolution algebra. Audit p. 8 gives a strict witness: N(D) = {0} can hold even when D admits no natural basis. The claimed comparison is therefore correct and strictly broader within evolution algebras.")
sub("Original low-dimensional claim without classification machinery")
p("For a two-dimensional complex evolution algebra: if dim E² = 2, the two natural-basis squares are independent, so N(E) = {0}; [LT] produces an idempotent. If dim E² = 1, let E² = Ku. Write u² = cu. For c ≠ 0, u/c is idempotent; for c = 0, E⁽³⁾ = 0. If E² = 0, E is already solvable. Dimension one is immediate. This independently establishes that dimension three is minimal for a complex counterexample. Direct sums of Example 2.1 with zero algebras give examples in every dimension ≥ 3. The phrase “any dimension” on [B] p. 2 needs that qualification.")
sub("Subsequent material: Remark 3.5")
p("The p. 4 remark reports that the authors have not found a perfect subspace of dimension &gt; 2 without a proper nonzero perfect subspace. It is a search observation and possible research question. This audit does not turn it into a theorem, settle the resulting classification problem, or infer that exhaustive search was performed. Acknowledgments and references add provenance and background, not further mathematical claims.", "small")

page(7, "Hu–Wen: the same counterexample class")
p("[HW], Theorem 2.1 and Corollary 2.2, pp. 2–3, give a one-parameter family, defined when char K ≠ 2 and λ ≠ 0:")
eq(r"h_1^2=-h_1-h_3,\quad h_2^2=-2h_1+\lambda h_2+(\lambda-2)h_3,\quad h_3^2=h_1+h_3.")
p("The exceptional λ = 2 member H₂ is idempotent-free and nonsolvable. For λ ≠ 2 their family has a nonzero idempotent. The λ = 2 matrix is")
matrix("Hu–Wen H₂", [[-1,0,-1],[-2,2,0],[1,0,1]])
sub("Explicit isomorphism, independently checked")
eq(r"\psi(e_1)=-h_2,\qquad \psi(e_2)=h_3,\qquad \psi(e_3)=-h_1.")
p("This is an invertible signed permutation of bases. The images of Barei’s three square relations are respectively 2h₂ − 2h₁, h₃ + h₁, and −h₃ − h₁. They agree with (−h₂)², h₃², and (−h₁)² using the Hu–Wen table. Distinct basis vectors map to distinct natural vectors, so all off-diagonal products also agree. Exact C04 checks all nine basis-product equalities and full rank of the change of basis.")
p("<b>Finding N-01:</b> Example 2.1 is not a new isomorphism class relative to the retrieved Hu–Wen paper. It gives the same counterexample by different coordinates. This mathematical overlap does not establish how either team found it, whether one knew the other’s construction, or the model’s training exposure.")
sub("Dates and what the evidence supports")
table(["Event / source", "Date evidence", "Status"], [
    ["Original conjecture, GP preprint", "13 Dec 2025", "arXiv 2512.12418 record; full preprint retrieved."],
    ["Original GP publication", "22 Apr 2026", "Publisher and printed front-page date; DOI verified."],
    ["Hu–Wen manuscript", "12 Aug 2026 reported", "PDF v1 banner gives this date; Barei p. 2 calls it the submission date."],
    ["Meta public release", "2 Oct 2026", "Official announcement dated; complete manuscript retrieved via its publication page."],
], [157, 113, 234])
p("<b>Chronology limit:</b> the Hu–Wen abstract/submission-history page could not be fetched in this run. Its arXiv identifier begins 2609, while the retrieved PDF banner says 12 Aug. Earlier draft dates can differ from posting dates; the sources here do not settle that discrepancy or Barei’s internal development dates. Hu–Wen is acknowledged as prior/concurrent work by the public Meta release; absolute discovery priority is not established.", "small")
p("Hu–Wen Remark 2.5 identifies the class in a 2017 classification. That older full text could not be retrieved (403/502), so its precise classification-row identification remains a <b>source assertion</b>. The direct isomorphism above requires only the two retrieved multiplication tables and is independently verified.", "small")

page(8, "A witness that the new condition is broader")
p("This audit constructs the following four-dimensional complex evolution algebra F with natural basis b₁,…,b₄. It is a scope witness; no claim of historical novelty is made for this construction.")
matrix("Structure matrix W", [[1,0,-1,0],[1,1,0,1],[0,1,-1,-1],[0,0,1,1]], width=185)
p("Exact products and row reduction show F² = D = {(x,y,z,x+z) : x,y,z ∈ ℂ}. The induced multiplication in coordinates (x,y,z) is")
eq(r"(x,y,z)(u,v,w)=(xu+yv,\;yv+zw,\;xw+zu).")
p("For coordinate vectors f₁,f₂,f₃, the products f₁² = f₁, f₂² = f₁ + f₂, and f₁f₃ = f₃ span D; hence D² = D and the derived dimensions are 4 → 3 → 3. C05 verifies the embedding and all nine basis-product identities.")
eq(r"v^2=(x^2+y^2,\;y^2+z^2,\;2xz).")
p("If v² = 0, then xz = 0. If x = 0, the first coordinate forces y = 0 and the second forces z = 0. If z = 0, the second forces y = 0 and the first forces x = 0. Thus <b>N(D) = {0}</b>. A nonzero idempotent is (1,0,0) in D, embedded as (1,0,0,1) in F.")
sub("D has no natural basis: an exact obstruction")
p("The coordinate bilinear forms of the displayed product have matrices B₁ = diag(1,1,0), B₂ = diag(0,1,1), and B₃ with entries 1 at (1,3),(3,1) and zero elsewhere. Their sum B₀ = B₁ + B₂ = diag(1,2,1) is invertible. Put A = B₀⁻¹B₁ = diag(1,1/2,0) and C = B₀⁻¹B₃.")
matrix("AC − CA", [[0,0,1],[0,0,0],[-1,0,0]])
p("If a natural basis existed, some invertible P would make <b>every</b> PᵀBⱼP diagonal, because products of distinct basis vectors would vanish in every coordinate. Then PᵀB₀P would be invertible diagonal, and")
eq(r"P^{-1}(B_0^{-1}B_j)P=(P^TB_0P)^{-1}(P^TB_jP)")
p("would also be diagonal. In particular A and C would be simultaneously diagonal under similarity and would commute. Their displayed nonzero commutator rules this out. C06 computes that obstruction and the idempotent exactly. Therefore F satisfies Barei’s N(D) = {0} hypothesis while failing Hu–Wen’s “D is an evolution algebra” hypothesis. This proves <b>strict</b> enlargement of the sufficient condition.")

page(9, "Scope tests and omitted assumptions")
p("These tests deliberately change a hypothesis or probe a converse. They are not counterexamples to the stated complex/algebraically closed-field theorems.")
sub("Ground field: algebraic closure matters, but is not minimal")
matrix("Over F₃", [[1,2],[1,1]], width=110)
p("This two-dimensional evolution algebra is perfect because its matrix is invertible. Enumeration of all 9 vectors gives N(E) = {(0,0)} and idempotents = {(0,0)}. Thus Theorem 3.3 and Corollary 3.4 would fail if one simply replaced “algebraically closed field” by “arbitrary field.” It is the example in [HW] Remark 2.7, independently reconstructed as C07.")
p("Algebraic closure is a sufficient field condition, not the sharp boundary. [LT] Theorem 2.2 / Corollary 2.3 gives, in characteristic ≠ 2, the idempotent-or-square-zero property for fields in which every odd-degree polynomial has a root. This includes ℝ and real closed fields. Those extensions are source-supported; this audit checks the algebraically closed-field proof and the finite-field counterexample, without re-auditing the full field-classification theorem.", "small")
sub("Characteristic two: the particular example changes")
p("Reduce Barei’s M modulo 2: the first row vanishes; the second and third rows equal (0,1,1). Their span is generated by u = e₂ + e₃ and u² = e₂² + e₃² = 0. The derived dimensions are 3 → 1 → 0 (then remain 0), reproduced by C08. This does not invalidate the abstract theorems in characteristic two.")
sub("The new hypothesis is sufficient, not necessary")
matrix("Complex matrix U", [[1,-1,0],[0,-1,-1],[0,1,1]])
p("Here D = span{u,v}, with u = (1,0,1), v = (0,1,1), has u² = u, uv = v, v² = 0 and D² = D. Hence E is nonsolvable and has an idempotent, while N(D) ≠ {0}. Both sides of the conjectured equivalence are false, so the equivalence holds for this individual algebra despite failing Corollary 3.4’s sufficient hypothesis. C09 verifies the dual-number multiplication and derived dimensions 3 → 2 → 2.")
sub("Closure, dimension, and a negative control")
p("The line ℂe₁ in Barei’s counterexample has no nonzero square-zero vector, yet contains no nonzero idempotent: e₁² = −2e₁ + 2e₃ leaves the line. Thus arbitrary square-zero-free <i>vector subspaces</i> cannot replace subalgebras in the converse of Theorem 3.3 (C11). The infinite-dimensional failure of stabilization and Theorem 3.2 is proved on audit p. 4.")
p("As a negative control, delete the +2e₃ coefficient in Barei’s e₁². The changed algebra acquires the idempotent −e₁/2, while that vector is not idempotent for the published matrix (C10). This tests that the arithmetic is sensitive to a coefficient that matters.", "small")

page(10, "Correctness, novelty, and AI attribution")
sub("Correctness conclusion")
p("All principal conclusions survive the independent reconstructions under their stated assumptions. The useful mathematical repairs are expository: include the exhaustive two-branch idempotent elimination; explicitly prove descent and stabilization; state the idempotent-or-square-zero lemma instead of an unlocated fixed-point assertion; use D directly in Corollary 3.4; qualify the dimension-extension phrase as n ≥ 3. No changed theorem statement is needed to repair the principal results.")
sub("Novelty conclusion, bounded to the retrieved literature")
p("The conjecture’s disproof already appears in the acknowledged Hu–Wen work, and Barei’s example is the same isomorphism class. Theorem 3.2 follows directly from the stable derived term and applies to general algebras. Theorem 3.3 is a useful formulation whose nontrivial converse follows from an older general existence theorem, available at least in [LT] (2014); its forward witness is a one-dimensional idempotent line. These observations qualify the abstract’s word “novel.”")
p("The specific added value relative to Hu–Wen is Corollary 3.4’s more general sufficient condition on D, together with a clean organizational viewpoint using perfect subspaces. The strict enlargement is independently proved on audit p. 8. The corollary itself is a short application of the older existence lemma to the stable term. <b>Global priority for this exact formulation remains unresolved</b>; the audit is not an exhaustive literature or prior-art search. Hu–Wen additionally supplies a parameter family and structural comparisons that the shorter Meta manuscript does not reproduce.")
sub("Attribution evidence, separate from mathematical correctness")
table(["Evidence supplied", "What it supports", "What it cannot reconstruct"], [
    ["[B] p. 1 Statement of AI Use", "Authors report model exploration, candidate arguments, drafting, and human checking/correction/ownership.", "Which ideas first arose in a model response, exact prompts, revisions, or discovery chronology."],
    ["Human / AI margin markers", "Example 2.1 and principal §3 arguments are marked AI-assisted; introduction and AI-use statement are marked Human. The p. 4 Human marker accompanies subsequent remarks.", "Fraction of intellectual contribution or independence from prior material; markers are author-supplied labels."],
    ["Meta’s 2 Oct announcement", "Reports that Muse Spark generated the counterexample and proposed characterizations/proofs; Barei checked, refined, and rewrote.", "An independent causal or provenance audit of those claims; underlying interactions are absent."],
    ["Named reviewer and acknowledgment", "Nicolás Jaramillo Torres is named as reviewer; Ricky Simanjuntak is thanked for discussion and feedback.", "Review details, checklists, version differences, or formal verification records."],
], [125, 187, 192])
p("<b>Attribution verdict:</b> the supplied material documents a stated collaboration, but provides no interaction logs, timestamped model outputs, prompts, search failures, or version history. Correct equations do not establish which participant generated them. Likewise, overlap with Hu–Wen does not establish dependence or copying. The contribution claim is plausible as an author report and cannot be independently reconstructed from the available evidence.", "small")

page(11, "Reproducible checks and actual results")
p("The accompanying <b>verify_audit.py</b> uses only Python’s standard library. It reconstructs natural-basis products, row spaces, derived terms, changes of basis, and a bilinear-form obstruction with <b>fractions.Fraction</b>. Finite-field tests use exact modular integers and enumerate every point in the specified finite fields. The complex idempotent check evaluates every analytically forced branch; it never samples complex numbers.")
p("Actual command: <font face='DVM'>python3 verify_audit.py --output results.json</font><br/>Actual exit code: <b>0</b>. Recorded Python version: <b>3.12.14</b>. Output: <b>PASS: 11 exact check groups</b>.")
table(["ID", "Checked result", "Actual outcome"], [
    ["C01", "Published r₁², r₁r₂, r₂² from M", "(−8,−4,12), (0,2,−2), (0,0,0)"],
    ["C02", "Derived series of Example 2.1", "Dimensions [3,2,2]; stable span = span{r₁,r₂}"],
    ["C03", "Exhaustive complex-idempotent branches", "x = 0 gives zero; x = −1/2 forces 0 = −1/4"],
    ["C04", "Signed-permutation isomorphism to HW E₂", "9 product identities; invertible basis map"],
    ["C05", "Four-dimensional strictness witness", "Dimensions [4,3,3]; 9 embedding identities"],
    ["C06", "Witness has no natural basis", "Nonzero commutator; idempotent (1,0,0,1)"],
    ["C07", "F₃ field-hypothesis test", "All 9 points: only zero square-zero and idempotent"],
    ["C08", "Published M in characteristic two", "Dimensions [3,1,0,0]; solvable"],
    ["C09", "Hypothesis not necessary for individual equivalence", "Perfect dual-number stable term; u²=u, v²=0"],
    ["C10", "Changed-coefficient negative control", "Changed matrix has idempotent (−1/2,0,0)"],
    ["C11", "Closure needed for square-zero-free witness", "ℂe₁ is square-zero-free; e₁² leaves it"],
], [41, 214, 249])
p("Every listed group returned <b>PASS</b>. <b>results.json</b> retains exact evidence and scope exclusions; <b>run_log.txt</b> records the actual output; <b>source_manifest.json</b> records URLs, pages, byte counts, and SHA-256 for each complete source. The optional build_report.py preserves this report’s authored text and requires ReportLab, Matplotlib, and DejaVu fonts only for PDF regeneration.")
p("<b>Limits of the code:</b> finite identities and an analytic branch check do not machine-verify the universal existence theorem, Bézout, all characteristic cases, the infinite-dimensional argument, or the implication from simultaneous congruence to commuting operators. Those are supplied as mathematical proofs in this report. The checks are not a proof-assistant formalization, an attribution audit, or an exhaustive novelty determination.", "small")

page(12, "Primary sources and unresolved records")
p("Complete PDFs of the seven sources below were retrieved. The audit uses the published original for printed locations. Source copies and their hashes were inspected locally; the package records retrieval identities without redistributing third-party texts.", "small")
refs = [
    ("[B] Barei, Andres, with Muse Spark (2026)",
     "On Solvable Evolution Algebras and a Conjecture by García-Martínez and Pérez-Rodríguez. Complete 5-page PDF linked from the official Meta publication page. Example 2.1 pp. 2–3; Lemma 3.1, Theorems 3.2–3.3 p. 3; Corollary 3.4 pp. 3–4; Remarks 3.5–3.6 p. 4. The user’s 6-page attachment is a publication-page printout, not this manuscript.",
     "https://ai.meta.com/research/publications/on-solvable-evolution-algebras-and-a-conjecture-by-garcia-martinez-and-perez-rodriguez/"),
    ("[GP] García-Martínez, Xabier; Pérez-Rodríguez, Andrés (2025/2026)",
     "A note on complete evolution algebras. Archiv der Mathematik 126, 597–604, online 22 Apr 2026. §3 fixes complex finite dimension; Theorem 3.5 and Conjecture 3.6 printed p. 602. Complete 8-page published PDF and 7-page preprint arXiv:2512.12418 retrieved.",
     "https://doi.org/10.1007/s00013-026-02251-0"),
    ("[HW] Hu, Xing-Yu; Wen, Ran (2026)",
     "Idempotent-free non-solvable evolution algebras over C. arXiv:2609.25023, retrieved v1 PDF, 8 pages. Family: Theorem 2.1 / Corollary 2.2 pp. 2–3; prior classification: Remark 2.5 pp. 4–5; finite-field example: Remark 2.7 p. 6; stable-term condition: Proposition 2.8 p. 6. Banner reports 12 Aug 2026; submission-history date unresolved.",
     "https://arxiv.org/pdf/2609.25023"),
    ("[LT] Lyubich, Yuri; Tsukerman, Alexander (2014)",
     "Idempotents in nonassociative algebras and eigenvectors of quadratic operators. arXiv:1403.4623, submitted 18 Mar 2014, 8 pages. Definition of general algebra p. 1; Theorem 2.1 p. 2; homogeneous system and Lemma 3.2 pp. 4–5; algebraically closed-field proof p. 5. This directly supplies the imported existence lemma.",
     "https://arxiv.org/abs/1403.4623"),
    ("[KT] Krasnov, Yakov; Tkachev, Vladimir G. (2018)",
     "Variety of idempotents in nonassociative algebras. arXiv:1801.00617, 27 pages. §2, pp. 4–5 gives further classical context on the squaring map, idempotents, square-zero elements, and Bézout. Context source; no further theorem from it is essential to the reconstructed proof.",
     "https://arxiv.org/abs/1801.00617"),
    ("[V] Vakil, Ravi (2005–2006)",
     "Foundations of Algebraic Geometry, class 31 notes, 8 pages. Proper-intersection Bézout exercise p. 4; complete-intersection degree discussion p. 6. Supports the correctly qualified degree product used in the reconstruction.",
     "https://math.stanford.edu/~vakil/0506-216/216class31.pdf"),
]
for title,desc,url in refs:
    p(title,"sub")
    p(desc,"small")
    # Use a short readable clickable source label to avoid wide unbroken URLs.
    p('<link href="'+escape(url,quote=True)+'" color="#176b62">Open primary source</link>',"small")
p("<b>Unresolved records:</b> Harris (1992), the manuscript’s general geometry citation, was not matched to an exact fixed-point passage. Cabrera Casado–Siles Molina–Velasco (2017), the older classification named by Hu–Wen, was not retrievable in full. Hu–Wen’s first-posting history and Meta’s internal research dates were not recovered. Interaction records and global novelty priority are unavailable. These limits do not alter the explicit counterexample proof or the independently supported existence dependency.", "small")
p('<b>Attribution source:</b> Meta, “Solving Open Research Problems Together,” 2 Oct 2026, sixth-paper section. <link href="https://research.meta.ai/blog/solving-open-research-problems-together" color="#176b62">Open official announcement</link>. No one was contacted and nothing was published as part of this audit.',"small")


def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#c7d3de"))
    canvas.line(54, 42, 558, 42)
    canvas.setFont("DV", 7)
    canvas.setFillColor(MUTED)
    canvas.drawString(54, 29, "Barei evolution-algebra audit • 3 October 2026 UTC • Bounded independent review")
    canvas.drawRightString(558, 29, str(doc.page))
    canvas.restoreState()


doc = SimpleDocTemplate(str(OUTPUT), pagesize=(612,792),
                        rightMargin=54,leftMargin=54,topMargin=47,bottomMargin=57,
                        title="Barei Evolution Algebra Audit",
                        author="Independent audit prepared for Mark",
                        subject="Correctness, scope, novelty, and AI-attribution review")
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(OUTPUT)
