"""Optional PDF builder; needs reportlab and matplotlib only for font discovery."""
from pathlib import Path
from html import escape
import csv
import hashlib
import json
import matplotlib
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Flowable

ROOT = Path(__file__).resolve().parent
FONT = Path(matplotlib.get_data_path()) / 'fonts/ttf'
pdfmetrics.registerFont(TTFont('Audit', str(FONT / 'DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('AuditBold', str(FONT / 'DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('Audit', normal='Audit', bold='AuditBold', italic='Audit', boldItalic='AuditBold')
INK = colors.HexColor('#18344F')
TEAL = colors.HexColor('#08786F')
MUTED = colors.HexColor('#566A7C')
PALE = colors.HexColor('#EAF5F3')
styles = {
    'body': ParagraphStyle('body', fontName='Audit', fontSize=10.0, leading=14.0, textColor=INK, spaceAfter=7),
    'small': ParagraphStyle('small', fontName='Audit', fontSize=8.7, leading=11.9, textColor=INK, spaceAfter=5),
    'title': ParagraphStyle('title', fontName='AuditBold', fontSize=21, leading=26, textColor=INK, spaceAfter=12),
    'heading': ParagraphStyle('heading', fontName='AuditBold', fontSize=12.3, leading=16, textColor=TEAL, spaceBefore=8, spaceAfter=6),
    'eyebrow': ParagraphStyle('eyebrow', fontName='AuditBold', fontSize=8.4, leading=11, textColor=TEAL, spaceAfter=9),
    'formula': ParagraphStyle('formula', fontName='Audit', fontSize=11.0, leading=16, textColor=INK, spaceAfter=9),
}
story = []

def p(text, style='body'):
    story.append(Paragraph(text, styles[style]))

def title(page, text):
    p('MATHWISE / MINIMALITY FOLLOW-UP / %02d' % page, 'eyebrow')
    p(text, 'title')

def table(rows, widths, font_size=8.6):
    data = [[Paragraph(str(cell), ParagraphStyle('cell', parent=styles['small'],
              fontSize=font_size, leading=font_size + 3)) for cell in row] for row in rows]
    t = Table(data, colWidths=widths, hAlign='LEFT')
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), PALE),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 7),
        ('RIGHTPADDING', (0, 0), (-1, -1), 7),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
        ('LINEBELOW', (0, 0), (-1, 0), .5, TEAL),
        ('LINEBELOW', (0, 1), (-1, -1), .2, colors.HexColor('#D3DFE6')),
    ]))
    story.append(t)
    story.append(Spacer(1, 9))

class Matrix(Flowable):
    def __init__(self, rows, label='', col=30, row=22):
        super().__init__()
        self.rows, self.label, self.col, self.row = rows, label, col, row
        self.left = 52 if label else 8
        self.width = self.left + len(rows[0]) * col + 13
        self.height = len(rows) * row + 8
    def draw(self):
        c = self.canv
        c.setFillColor(INK)
        c.setFont('Audit', 11)
        if self.label:
            c.drawString(0, self.height / 2 - 4, self.label)
        x0, x1 = self.left, self.width - 5
        y0, y1 = 4, self.height - 3
        c.setStrokeColor(INK)
        c.setLineWidth(.7)
        for x, delta in [(x0, 4), (x1, -4)]:
            path = c.beginPath()
            path.moveTo(x + delta, y1)
            path.lineTo(x, y1)
            path.lineTo(x, y0)
            path.lineTo(x + delta, y0)
            c.drawPath(path)
        for i, line in enumerate(self.rows):
            for j, value in enumerate(line):
                c.drawCentredString(x0 + 9 + self.col * (j + .5), y1 - self.row * (i + .7), str(value))

def matrix(rows, label=''):
    story.append(Matrix(rows, label))
    story.append(Spacer(1, 9))

def footer(canvas, doc):
    canvas.setStrokeColor(colors.HexColor('#CBD7DF'))
    canvas.setLineWidth(.4)
    canvas.line(48, 39, 564, 39)
    canvas.setFont('Audit', 7.0)
    canvas.setFillColor(MUTED)
    canvas.drawString(48, 26, 'Commissioned by Mark S. Weinstein / 3 October 2026 / Saved for review; not published')
    canvas.drawRightString(564, 26, str(doc.page))

title(1, 'Four dimensions are minimal')
p('<b>Verdict.</b> Over the complex numbers, the least ambient dimension is <b>4</b> for an evolution algebra E whose stable derived term D satisfies N(D) = {0} but admits no natural basis. The earlier four-dimensional witness supplies the upper bound; the elementary argument below supplies the lower bound.')
p('This is a source-informed, AI-assisted follow-up commissioned by Mark S. Weinstein, in the same assistant workflow as the earlier audit. It is a reconstructed proof, with supporting exact calculations, not a claim of historical novelty or independent human expert review.', 'small')
p('1. Definitions and stable-term closure', 'heading')
p('A natural basis has zero products between distinct basis vectors. Multiplication is bilinear and commutative; associativity is not assumed. Write V² = span{uv : u,v ∈ V}, E<super>(1)</super> = E and E<super>(k+1)</super> = (E<super>(k)</super>)². Also N(D) = {d ∈ D : d² = 0}; this is a set, not an assumed vector subspace.')
p('If W is a subalgebra, W² ⊆ W and products of elements of W² lie in W². Thus each derived term is a subalgebra and the series descends. Finite dimension gives stabilization, so D is a commutative subalgebra and D² = D. We make no assertion that D has a natural basis inherited from E.')
p('2. The low-dimensional lemma', 'heading')
p('<b>Lemma.</b> Every commutative complex algebra A of dimension at most two with N(A) = {0} admits a natural basis. In dimensions zero and one, respectively use the empty basis and any single basis vector.')
p('<b>Proof in dimension two.</b> Choose a basis a,b and let L<sub>u</sub>(v) = uv. If L<sub>a</sub> is singular, take u = a. Otherwise det(L<sub>b</sub> + tL<sub>a</sub>) is a quadratic in t with nonzero leading coefficient det(L<sub>a</sub>). Since C is algebraically closed, it has a root t₀. Take u = b + t₀a ≠ 0; then L<sub>u</sub> is singular.')
p('Choose 0 ≠ v ∈ ker L<sub>u</sub>. Since u² ≠ 0, u is not in this kernel, and u,v are independent. Their mixed product uv is zero. Commutativity therefore makes {u,v} a natural basis. This proves the lemma without assuming A² = A or importing a classification theorem.')
p('3. Every smaller ambient case is excluded', 'heading')
table([['dim D, when dim E ≤ 3', 'Reason the target cannot hold'],
       ['0', 'The empty basis makes the zero algebra an evolution algebra.'],
       ['1', 'Every one-dimensional algebra has a natural basis.'],
       ['2', 'N(D) = {0} gives a natural basis by the lemma.'],
       ['3', 'Then dim E = 3 and D = E, which is already an evolution algebra.']], [164, 340])
p('Equivalently, the target forces dim D ≥ 3 and D ≠ E, so dim E ≥ dim D + 1 ≥ 4. The convention including the zero algebra via its empty natural basis is explicit here.', 'small')

story.append(PageBreak())
title(2, 'The witness, reconstructed')
p('The structure matrix below is the construction in the earlier audit, p. 8, and published checker C05-C06. It is carried forward and rechecked here; the minimality proof on p. 1 is the additional conclusion of this follow-up.')
p('Let E have natural basis e₁,e₂,e₃,e₄ with eᵢeⱼ = 0 for i ≠ j. Row i of W gives eᵢ², so all multiplication conventions match the published record.')
matrix([[1,0,-1,0],[1,1,0,1],[0,1,-1,-1],[0,0,1,1]], 'W =')
p('In particular, e₁² = e₁ - e₃; e₂² = e₁ + e₂ + e₄; e₃² = e₂ - e₃ - e₄; and e₄² = e₃ + e₄.')
p('4. Its stable term has dimension three', 'heading')
p('Put f₁ = e₁ + e₄, f₂ = e₂, f₃ = e₃ + e₄. All four rows lie in the hyperplane with fourth coordinate equal to the sum of the first and third. They span it: f₃ = e₄², f₁ = e₁² + e₄² and f₂ = e₂² - f₁. Consequently')
p('E² = D = {(x,y,z,x+z) : x,y,z ∈ C}.', 'formula')
p('Identify D with C³ through (x,y,z) ↦ xf₁ + yf₂ + zf₃. Direct bilinear multiplication from W gives')
p('(x,y,z)(u,v,w) = (xu+yv, yv+zw, xw+zu).', 'formula')
p('The products f₁² = f₁, f₂² = f₁ + f₂ and f₁f₃ = f₃ span D. Hence D² = D, and the derived dimensions are <b>4 → 3 → 3</b>. Here E² is already the stable derived term.')
p('5. Every square-zero solution is covered', 'heading')
p('The induced square map is')
p('Q(x,y,z) = (x²+y², y²+z², 2xz).', 'formula')
p('If Q(x,y,z) = 0, then xz = 0 because 2 ≠ 0 in C. If x = 0, the first equation forces y = 0 and the second forces z = 0. If z = 0, the second equation forces y = 0 and the first forces x = 0. Those two cases cover every complex solution. Thus <b>N(D) = {0}</b>.')
p('No bounded enumeration or approximation of complex solutions is used. Checks M01-M03 confirm the exact embedding, spanning products and polynomial coefficients; the exhaustive implication above is a mathematical argument.', 'small')

story.append(PageBreak())
title(3, 'Its stable term has no natural basis')
p('6. A necessary condition gives a contradiction', 'heading')
p('The three coordinate bilinear forms of the product on p. 2 have matrices')
mats = [[1,0,0],[0,1,0],[0,0,0]], [[0,0,0],[0,1,0],[0,0,1]], [[0,0,1],[0,0,0],[1,0,0]]
t = Table([[Paragraph('B₁', styles['formula']), Paragraph('B₂', styles['formula']), Paragraph('B₃', styles['formula'])],
           [Matrix(mats[0]), Matrix(mats[1]), Matrix(mats[2])]], colWidths=[164,164,176], hAlign='LEFT')
t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0)]))
story.append(t)
story.append(Spacer(1,10))
p('Let B₀ = B₁ + B₂ = diag(1,2,1), which is invertible. Set A = B₀<super>-1</super>B₁ = diag(1,1/2,0) and C = B₀<super>-1</super>B₃. Their commutator is')
matrix([[0,0,1],[0,0,0],[-1,0,0]], 'AC-CA =')
p('Suppose D had a natural basis whose coordinate columns form an invertible matrix P. Every mixed basis product would vanish in every output coordinate, so every P<super>T</super>BⱼP (j = 1,2,3) would be diagonal. Their sum P<super>T</super>B₀P would also be invertible diagonal.')
p('For each j, the following identity then makes the left-hand side diagonal:')
p('P<super>-1</super>(B₀<super>-1</super>Bⱼ)P = (P<super>T</super>B₀P)<super>-1</super>(P<super>T</super>BⱼP).', 'formula')
p('In particular, A and C would become diagonal under the same similarity and would commute. The displayed nonzero commutator contradicts that consequence. Therefore <b>D admits no natural basis</b>. This uses only a necessary condition, not an imported simultaneous-diagonalization classification. M04 verifies the finite matrix data exactly.')
p('Combining pp. 1-3 establishes both the lower and upper bounds. <b>The minimum is exactly four.</b> The same witness shows that dimension three is the least intrinsic dimension of a commutative complex square-zero-free algebra without a natural basis.')
p('7. A useful consequence for the sufficient conditions', 'heading')
p('For any complex evolution algebra of ambient dimension at most three, the conditions <b>N(D) = {0}</b> and <b>D is an evolution algebra</b> coincide. The forward direction is the dimension argument on p. 1.')
p('For the converse in any finite dimension, if D has a natural basis g₁,...,gₘ, its basis squares span D because D² = D. Those m squares are therefore independent. For d = Σcᵢgᵢ, the equation d² = Σcᵢ²gᵢ² = 0 forces every cᵢ = 0. The zero-dimensional case is vacuous. This is Barei’s Remark 3.6, rederived here. The first strict separation is attained by the four-dimensional witness.')

story.append(PageBreak())
title(4, 'Degenerate cases and exact checks')
p('8. What the short lemma covers', 'heading')
p('<b>Singular multiplication operators.</b> The singular branch in the lemma is intentional. Under N(A) = {0}, a nonzero u cannot have L<sub>u</sub> = 0 because that would give u² = 0. A singular L<sub>u</sub> in dimension two therefore has rank one, and its kernel supplies the second natural-basis vector. No assumption that some L<sub>u</sub> is invertible is required.')
p('<b>Degenerate product image.</b> If dim A² = 0 in a nonzero algebra, every square is zero. If dim A² = 1 in dimension two, squares have the form q(x,y)c for a fixed nonzero c and a homogeneous binary quadratic q. If q = 0, every vector is square-zero. Otherwise q has a nonzero complex zero: if its x² coefficient is zero, (1,0) is a zero; if that coefficient is nonzero, q(t,1) has a complex root. Thus both product-image cases violate N(A) = {0}.')
p('<b>Field boundary.</b> Over R, the algebra with a² = a, ab = b, b² = -a has no nonzero square-zero element, since a square has coordinates (x²-y², 2xy). But det L<sub>xa+yb</sub> = x²+y² &gt; 0 for every nonzero real vector; no two independent real vectors can have zero product. Over C, the determinant roots ±i instead give a natural basis. This is a deliberate change of field, not a counterexample to the lemma.')
p('<b>Removing the square-zero hypothesis.</b> The complex dual numbers a² = a, ab = b, b² = 0 have no natural basis: if uv = 0 and either vector has nonzero a-coordinate, that vector’s multiplication operator is invertible and the other vector is zero; otherwise both vectors lie on Cb. Thus no independent zero-product pair exists.')
p('9. Actual supporting computations', 'heading')
table([['Check', 'Exact data or control verified'],
       ['M01', 'Nine witness embedding and basis-product identities.'],
       ['M02', 'Derived dimensions [4,3,3] and spanning products.'],
       ['M03', 'Square-map coefficients (x²+y², y²+z², 2xz).'],
       ['M04', 'B₀ inverse and nonzero commutator.'],
       ['M05', 'Formal determinant identity with six independent structure constants.'],
       ['M06', 'Initially singular operator yields independent zero-product vectors.'],
       ['M07', 'Nonreal roots and basis verified exactly over rational pairs Q(i).'],
       ['M08', 'Zero-image and rank-one product-image controls.'],
       ['M09', 'Dual-number square-zero and determinant data.']], [64,440], 8.2)
p('Python 3.12.14, exit code 0: <b>9/9 groups PASS</b>. The unchanged published checker also ran with <b>11/11 PASS</b>; its eleven check records match the published results. Actual executions: 3 October 2026, 20:04:29 UTC (4:04:29 p.m. EDT). The programs check exact finite data and a formal polynomial identity, not the entire universal proof.', 'small')

story.append(PageBreak())
title(5, 'Sources, addendum, and review package')
p('10. Exact source locations and dependencies', 'heading')
commit = 'a52a1caf3c7e2f560eb9c3ee01f676153d299f83'
base = 'https://github.com/Grounded-DI/MathWise/blob/' + commit + '/audits/2026-10-03-barei-evolution-algebras/'
meta = 'https://ai.meta.com/research/publications/on-solvable-evolution-algebras-and-a-conjecture-by-garcia-martinez-and-perez-rodriguez/'
p('Current main inspected at commit <b>a52a1caf3c7e2f560eb9c3ee01f676153d299f83</b>. The local detailed report, published note, checking code and recorded results match the pinned tree’s Git blob identities and sizes.', 'small')
p('Earlier audit: <a href="' + base + 'input_record/Barei_Evolution_Algebra_Audit.pdf" color="#08786F">detailed report p. 8</a>, construction and obstruction; p. 4, stable-term closure. <a href="' + base + 'verify_audit.py" color="#08786F">Published checker lines 152-184</a>, C05-C06; its actual results are in evidence/results_rechecked.json. These establish the carried-forward witness, now rechecked.', 'small')
p('<a href="' + meta + '" color="#08786F">Barei’s official paper</a>: natural-basis definition, p. 1; §2, derived series and N(V), p. 2; Corollary 3.4, pp. 3-4; Remark 3.6, p. 4. <a href="https://arxiv.org/pdf/2609.25023" color="#08786F">Hu-Wen</a>: natural basis and row-matrix convention, p. 1; Proposition 2.8, p. 6. Both complete primary manuscripts were retrieved for this follow-up.', 'small')
p('The low-dimensional lemma and lower bound are proved here, not attributed to an imported classification or idempotent-existence theorem. The only root-existence input is the stated algebraic closure of C; the remaining steps are elementary linear algebra and bilinearity. No essential imported mathematical dependency is unresolved. Historical priority for this lemma or minimality statement was not established.', 'small')
p('11. Proposed addendum to the existing audit', 'heading')
addendum = '''<b>Minimal ambient dimension of the strictness witness.</b> The four-dimensional construction in this audit has the least possible ambient dimension over C among evolution algebras whose stable term D has N(D) = {0} but no natural basis.

Indeed, any commutative complex algebra A of dimension two with N(A) = {0} admits a natural basis. For a basis a,b, write L<sub>u</sub>(v) = uv. If L<sub>a</sub> is singular, take u = a; otherwise the quadratic det(L<sub>b</sub> + tL<sub>a</sub>) has a complex root t₀, giving nonzero u = b + t₀a with L<sub>u</sub> singular. Choose 0 ≠ v in its kernel. Since u² ≠ 0, u,v are independent; uv = 0 makes them a natural basis. Dimensions zero and one are immediate.

Thus D without a natural basis and with N(D) = {0} must have dimension at least three. Since D ≠ E, the ambient dimension is at least four. The existing witness attains that bound. Consequently Barei’s and Hu-Wen’s sufficient hypotheses coincide in ambient dimensions at most three and first separate in dimension four. This is a proof reconstructed for the audit follow-up; no historical novelty claim is made.'''
for part in addendum.split('\n\n'):
    p(part, 'small')
p('12. Reproduce and interpret the evidence', 'heading')
p('From the package directory, run with Python 3.8+ and the standard library, without -O:<br/><b>python3 verify_minimality.py --output my_results.json</b><br/><b>python3 input_record/verify_audit.py --output my_original_results.json</b>', 'small')
p('The package contains both exact programs, actual results and stdout logs, a dated run record, source locations, this report and the addendum text. SHA-256 inventories identify the packaged bytes; successful replay and hash checks remain separate from mathematical correctness. The original audit is included unchanged. Nothing was published or sent to anyone during this follow-up.', 'small')
p('Credit and scope: Andres Barei’s manuscript credits Muse Spark and names Nicolás Jaramillo Torres as reviewer; the comparison acknowledges Hu and Wen. This follow-up adds a minimality proof to the earlier audit witness. No blind replication, independent human expert review, formal proof verification, historical novelty, endorsement, or causal benefit from Protocol A is claimed.', 'small')

plain_addendum = addendum.replace('<b>', '').replace('</b>', '').replace('<sub>u</sub>', '_u').replace('<sub>a</sub>', '_a').replace('<sub>b</sub>', '_b')
(ROOT / 'PROPOSED_ADDENDUM.txt').write_text(plain_addendum + '\n')
doc = SimpleDocTemplate(str(ROOT / 'Barei_Witness_Minimality_Followup.pdf'),
    pagesize=letter, leftMargin=48, rightMargin=60, topMargin=44, bottomMargin=53,
    title='Four dimensions are minimal: Barei audit witness follow-up',
    author='Source-informed AI-assisted audit commissioned by Mark S. Weinstein',
    subject='Minimal ambient dimension over the complex numbers; separate follow-up saved for review')
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print('Created', ROOT / 'Barei_Witness_Minimality_Followup.pdf')
